﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BalloonController : MonoBehaviour {

    //how much it grows each time
    public float scaleFactor = 1.2f;

    //maximum scale
    public float maxScale = 3;

    void Start()
    {
        if(scaleFactor <= 1)
        {
            print("scale factor is too small!");
        }
    }

    // Detect mouse presses
    void OnMouseDown()
    {
        // increase the scale
        //transform.localScale = transform.localScale * scaleFactor;
        transform.localScale *= scaleFactor;

        // check if we've passed the maxScale
        if(transform.localScale.x >= maxScale)
        {
            // if so, we want to destroy the balloon
            Destroy(gameObject);
        }
    }
}
