﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour {

    // score of the player
    public int score = 0;

    // high score of the game
    public int highScore = 0;

    // static instance of the GM can be accessed from anywhere
    public static GameManager instance;

    void Awake()
    {
        // check that it exists
        if(instance == null)
        {
            //assign it to the current object
            instance = this;
        }

        // make sure that it is equal to the current object
        else if(instance != this)
        {
            // destroy the current game object - we only need 1 and we already have it!
            Destroy(gameObject);
        }

        // don't destroy this object when changing scenes!
        DontDestroyOnLoad(gameObject);
    }

    // increase the player score
    public void IncreaseScore(int amount)
    {
        // increase score by the amount
        score += amount;

        // show the new score
        print("new score: " + score);

        // have we surpassed our high score?
        if(score > highScore)
        {
            // save a new high score
            highScore = score;

            print("new record! " + highScore);
        }
    }
}
