﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeController : MonoBehaviour {
    
    public float speed = 0.1f;

    public float minY = -10;
    public float maxY = 10;

    Vector3 vector;

    void Start()
    {
        vector = new Vector3(1, 1, 1);
    }

    // Update is called once per frame
    void Update () {
        transform.position += speed * vector;
        // += transform.position = transform.position + Vector3.up

        // we want our cube to move up and down between y = -10 and y = 10

        // if we reached y = 10 and we were moving up, then we now need to go down
        if(transform.position.y >= maxY && speed > 0)
        {
            speed *= -1;
        }

        else if(transform.position.y <= minY && speed < 0)
        {
            speed *= -1;
        }
        // also, if we reached y = -10 and were moving down, then we need to move up
    }
}
